/* Programma che stampa Ciao Mondo! */

class CiaoMondo {
  public static void main(String args[]){

    System.out.println("Ciao Mondo!");

  }
}
