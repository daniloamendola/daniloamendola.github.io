/* Programma che calcolo l'area di un triangolo */

class AreaDiUnTriangolo {
  public static void main(String args[]){
    int base;
    int altezza;
    int area;

    base = 4;
    altezza = 10;
    area = base * altezza / 2;
    System.out.println(area);  
  }
}
