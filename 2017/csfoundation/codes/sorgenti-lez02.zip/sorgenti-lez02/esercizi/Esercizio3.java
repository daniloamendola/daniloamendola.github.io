public class Esercizio3 {
  /*
  * Data base e altezza di un rettangolo, calcolare la
  * lunghezza della diagonale.
  */
  public static void main(String[] args) {
    double base = 30;
    double altezza = 40;
    System.out.println("Diagonale : " + Math.sqrt(base * base + altezza * altezza));
  }
}
