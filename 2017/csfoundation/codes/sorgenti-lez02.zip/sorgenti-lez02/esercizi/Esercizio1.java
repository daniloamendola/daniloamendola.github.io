
public class Esercizio1 {
	/*
	* Dati due numeri interi a e b, calcolare il quoziente e il
	* resto della divisione (intera) di a con b.
	*/
	public static void main(String[] args) {
		int a = 5;
		int b = 2;

		int quoziente = a / b;
		int resto = a % b;

		System.out.println("Quoziente : " + quoziente);
		System.out.println("Resto     : " + resto);
		System.out.println("Prova     : " +
		b + " * " + quoziente + " + " + resto + " = " +
		(b * quoziente + resto));
	}
}
