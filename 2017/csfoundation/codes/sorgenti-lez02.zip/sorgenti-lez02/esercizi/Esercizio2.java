public class Esercizio2 {
	/*
	* Dati due numeri "reali" a e b, calcolare il quoziente e il
	* resto della divisione (intera) di a con b.
	*/
	public static void main(String[] args) {
		double a = 5;
		double b = 2;

		int c = (int)a;
		int d = (int)b;

		int quoziente = c / d;
		int resto = c % d;

		System.out.println("Quoziente : " + quoziente);
		System.out.println("Resto     : " + resto);
		System.out.println("Prova     : " +
		d + " * " + quoziente + " + " + resto + " = " +
		(d * quoziente + resto));
	}
}
