/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */


class IfThenElse{
  public static void main(String args []) {
    int a = 10;
    final int b = 5;
    if (a > b)
      System.out.println("a > b");
    else
      System.out.println("a <= b");

    System.out.println("controllo effettuato");
  }
}
