/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */
  
class Confronti {
  public static void main(String args []) {
    int a = -20, b = 30, c = 0, d = 17;
    boolean primo = a > b;
    boolean secondo = c < d;
    System.out.println(primo);
    System.out.println(secondo);
  }
}
