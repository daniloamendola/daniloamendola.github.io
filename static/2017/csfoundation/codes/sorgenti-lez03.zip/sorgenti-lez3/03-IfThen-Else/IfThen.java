/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */
  
class IfThen{
  public static void main(String args []) throws IOException {

    System.out.println("m - maschio, f - femmina");
    char mf = (char) System.in.read();
    if (mf == ’m’) System.out.println("Maschio");
    System.out.println("Non maschio");
    /* Non è detto che si sia impostato f per femmina */
  }
}
