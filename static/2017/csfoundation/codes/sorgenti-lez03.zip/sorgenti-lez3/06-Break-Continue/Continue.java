/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */

class Continue{
  public static void main(String args []) {
    final int limite = 10;

    for (int conta = 1; conta < limite; conta++) {
      if (conta == 5) continue;
      System.out.println(conta);
    }
  }
}
