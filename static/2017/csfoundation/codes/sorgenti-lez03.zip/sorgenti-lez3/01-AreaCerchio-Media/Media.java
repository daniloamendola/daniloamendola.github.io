/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */
  
class Media {
  public static void main(String args []) {
    int a = 1, b = 3, c = 9, d = 20;
    int media = 0; /* Inizialmente media è posta a 0 */
    media = (a + b + c + d) / 4;
    System.out.println(media);
  }
}
