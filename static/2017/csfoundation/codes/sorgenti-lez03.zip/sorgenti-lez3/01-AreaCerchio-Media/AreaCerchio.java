/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */
  
class AreaCerchio {

  public static void main(String args []) {
    double raggio = 3.5;
    double area = raggio * raggio * 3.14; // 3.14 è una costante
    System.out.println(area);
  }
}
