/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */
  
import java.util.*;

class DoWhile{
  public static void main(String args []) {
    Scanner scan = new Scanner(System.in);
    String c;
    do {
      System.out.println("Vuoi che ti faccia ancora questa domanda? " );
      c = scan.next();
    } while(c.equals("s") || (c.equals("n")));
  }
}
