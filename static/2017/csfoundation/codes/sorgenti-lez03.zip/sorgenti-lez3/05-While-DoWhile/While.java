/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */
  
class While{
  public static void main(String args []) {
    int conta = 0;
    final int limite = 10; // è bene utilizzare sempre costanti
    while(conta < limite) {
      System.out.println(conta);
      conta = conta + 1; // oppure conta++;
    }
  }
}
