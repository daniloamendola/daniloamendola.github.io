
/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */

import java.util.*;

class MediaWhile {
  public static void main(String args []) {
    Scanner tastiera = new Scanner(System.in);
    System.out.print("Quante medie tra 4 numeri vuoi calcolare? ");
    int num_medie = tastiera.nextInt();
    int i = 0;
    int a, b, c, d;
    while( i < num_medie){
      System.out.print("Dammi 4 numeri interi: ");
      a = tastiera.nextInt();
      b = tastiera.nextInt();
      c = tastiera.nextInt();
      d = tastiera.nextInt();
      int media = 0; /* Inizialmente media è posta a 0 */
      media = (a + b + c + d) / 4;
      System.out.println("La media è " + media);
      i++;
    }
  }
}
