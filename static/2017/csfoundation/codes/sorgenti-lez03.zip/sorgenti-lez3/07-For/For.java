/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  * Una semplice classe che mostra il for che conta fino a un numero limite
  */

class For{
  public static void main(String args []) {
    final int limite = 10;
    for (int conta = 1; conta < limite; conta++)
      System.out.println(conta);
  }
}
