/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */

class TabellaPitagorica{
  public static void main (String args[]){
    System.out.prinln("Tavola Pitagorica:");
    int prod = 0;
    //Il programma cicla con due for innestati
    for (int riga=1; riga<=10; riga++){
      for (int colonna=1; colonna<=10; colonna++){
        prod = riga * colonna;
        System.out.print(prod + "\t");
      }
      System.out.print("\n"); // avremmmo potuto usare println semplicemente
    }
  }
}
