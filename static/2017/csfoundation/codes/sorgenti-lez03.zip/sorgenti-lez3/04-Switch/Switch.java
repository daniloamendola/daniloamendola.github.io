/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */

class Switch{
  public static void main(String args []) {
    // mese iniziale, mese finale, giorni passati
    int m_ini = 1, m_fin = 12, g = 0; // inizializzo le varibili


    // switch con condition sulla variabile m
    switch(m_ini) {
      case 1: g += 31; // gennaio
        if (m_fin <= 1) break;
      case 2: g += 28; // febbraio
        if (m_fin <= 2) break;
      case 3: g += 31; // marzo
        if (m_fin <= 3) break;
      case 4: g += 30; // aprile
        if (m_fin <= 4) break;
      case 5: g += 31; // maggio
        if (m_fin <= 5) break;
      case 6: g += 30; // giugno
        if (m_fin <= 6) break;
      case 7: g += 31; // luglio
        if (m_fin <= 7) break;
      case 8: g += 31; // agosto
        if (m_fin <= 8) break;
      case 9: g += 30; // settembre
        if (m_fin <= 9) break;
      case 10: g += 31; // ottobre
        if (m_fin <= 10) break;
      case 11: g += 30; // novembre
        if (m_fin <= 11) break;
      case 12: g += 31; // dicembre
        break;
      default: System.out.println("Errore");
    }
      System.out.println("I giorni dal mese " + m_ini + " al mese " + m_fin +  " sono " + g);
  }
}
