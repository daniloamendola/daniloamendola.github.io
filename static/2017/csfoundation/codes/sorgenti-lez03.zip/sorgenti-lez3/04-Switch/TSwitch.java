/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */

class TSwitch{
public static void main(String args []) {

    int a = 30;

    switch(a){
      case 30:
        System.out.println("Trenta");
        //break;
      case 29:
        System.out.println("Ventinove");
        break;
      default:
        System.out.println("Default");
        break;
    }//switch
    System.out.println("Fine");

  }
}
