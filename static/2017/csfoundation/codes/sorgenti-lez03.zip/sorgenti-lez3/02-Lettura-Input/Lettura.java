/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */
  
import java.util.*;

  class Lettura{
    public static void main(String args []) {
      Scanner tastiera = new Scanner(System.in);
      System.out.print("Nome: ");

      String nome = tastiera.next();
      System.out.print("Età: ");
      int età = tastiera.nextInt();

      System.out.print(nome);
      System.out.println(età);
    }
  }
