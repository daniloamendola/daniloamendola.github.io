/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */

import java.io.*;

public class Input {
  public static void main(String[] args) throws IOException {
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in)); System.out.print("Inserisci a: ");
    String linea1 = in.readLine();
    System.out.print("Inserisci b: ");

    String linea2 = in.readLine();
    int a = Integer.parseInt(linea1);
    int b = Integer.parseInt(linea2);
    System.out.println( a * b );
  }
}
