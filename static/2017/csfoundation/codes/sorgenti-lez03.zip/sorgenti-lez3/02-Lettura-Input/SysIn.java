
import java.io.*;

// Esempio di System.in

public class SysIn{

  public static void main (String args[]) throws IOException{

    System.out.println("Leggo un carattere");
    char c = (char) System.in.read();

    System.out.println("Il carattere è " + c);

  }
}
