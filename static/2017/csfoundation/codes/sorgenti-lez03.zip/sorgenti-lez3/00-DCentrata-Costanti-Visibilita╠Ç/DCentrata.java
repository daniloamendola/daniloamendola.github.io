public class DCentrata{
  public static void main(String[] args)
  {
    System.out.println("DDDD");
    System.out.println("DDDDDD");
    System.out.println("DD  DDD");
    System.out.println("DD   DDD");
    System.out.println("DD   DDD");
    System.out.println("DD   DDD");
    System.out.println("DD   DDD");
    System.out.println("DD  DDD");
    System.out.println("DDDDDD");
    System.out.println("DDDD");
  }
}
