/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */

class Costanti {
  public static void main(String args []) {
    double celsius = 18.0, fahrenheit; //inizializzare sempre!
    final int costante = 32;
    fahrenheit = (celsius * 9/5.0) + costante; //divisione reale
    System.out.println(fahrenheit);
  }
}
