/**
  * Esempi del corso di Fondamenti di Informatica
  * Sample for Computer Science Foundation
  * Univestity of Trieste
  * @author D.Amendola
  *
  *
  */

class Visibilita{

  public static void main (String args[]){

    int a = 1, b = 2;
    {
      // esempio 1
      int c = 1;
      System.out.println("C = " + c); // permesso c è nello stesso blocco
      // esempio 2
      c = a + b;
      System.out.println("C = " + c); // permesso c vede a e b

    }
    // esempio 3
    //System.out.println("C = " + c); // non permesso perchè c non è visibile qui
  }

}
