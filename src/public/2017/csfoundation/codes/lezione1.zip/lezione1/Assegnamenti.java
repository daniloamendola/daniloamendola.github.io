import java.util.*;

class Assegnamenti{

public static void main( String[] argomenti ){
    
  byte aByte = (byte)0b01100001;
  char bChar = (char)aByte; //255;
  int bInt = (int)aByte;

  System.out.println("aByte->" + aByte);
  System.out.println("cChar->" + bChar);
  System.out.println("bInt->" + bInt);


  }
}
